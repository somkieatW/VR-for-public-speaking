﻿#
#   Hello World server in Python
#   Binds REP socket to tcp://*:5555
#   Expects b"Hello" from client, replies with b"World"
#


import pyaudio
import sys
import wave
import time
import zmq
import speech_recognition as sr

context = zmq.Context()
socket = context.socket(zmq.REP)
socket.bind("tcp://*:5555")

mysp=__import__("my-voice-analysis")
print(55555)


while True:
    #  Wait for next request from client
    message = socket.recv()
    print("Received request: %s" % message)

    CHUNK = 1024
    FORMAT = pyaudio.paInt16
    CHANNELS = 2
    RATE = 44100
    RECORD_SECONDS = 10
    WAVE_OUTPUT_FILENAME = "output.wav"

    p = pyaudio.PyAudio()

    stream = p.open(format=FORMAT,
                    channels=CHANNELS,
                    rate=RATE,
                    input=True,
                    frames_per_buffer=CHUNK)

    print("* recording")

    frames = []

    for i in range(0, int(RATE / CHUNK * RECORD_SECONDS)):
        data = stream.read(CHUNK)
        frames.append(data)

    print("* done recording")

    stream.stop_stream()
    stream.close()
    p.terminate()

    wf = wave.open(WAVE_OUTPUT_FILENAME, 'wb')
    wf.setnchannels(CHANNELS)
    wf.setsampwidth(p.get_sample_size(FORMAT))
    wf.setframerate(RATE)
    wf.writeframes(b''.join(frames))
    wf.close()

    p="output" # Audio File title
    c=r"C:\Users\Acer\Desktop\lol\Unity3D-Python-Communication\PythonFiles" # Path to the Audio_File directory (Python 3.7)
    mysp.myspgend(p,c)
    mysp.mysppaus(p,c)
    print(555)

    r = sr.Recognizer()
    with sr.WavFile("output.wav") as source:              # ใช้ "test.wav"  เป็นแหล่งให้ข้อมูลเสียง
        audio = r.record(source)                        # ส่งข้อมูลเสียงจากไฟล์
    try:
        print("Transcription: " + r.recognize_google(audio))   # แสดงข้อความจากเสียงด้วย Google Speech Recognition
    except sr.RequestError as e:                                 # ประมวลผลแล้วไม่รู้จักหรือเข้าใจเสียง
        print("Could not understand audio")
    text = r.recognize_google(audio)
    storeText = text


    data = text
    words = data.split()

    unwanted_chars = ".,-_"
    wordfreq = {}
    for raw_word in words:
        word = raw_word.strip(unwanted_chars)
        if word not in wordfreq:
            wordfreq[word] = 0 
        wordfreq[word] += 1
        num = wordfreq[word]
        
        
    print(sorted(wordfreq.items(), key = 
                 lambda kv:(kv[1], kv[0]))) 
        

        

    #  Do some 'work'.
    #  Try reducing sleep time to 0.01 to see how blazingly fast it communicates
    #  In the real world usage, you just need to replace time.sleep() with
    #  whatever work you want python to do, maybe a machine learning task?
    time.sleep(1)

    #  Send reply back to client
    #  In the real world usage, after you finish your work, send your output here
    socket.send(sorted(wordfreq.items(), key = 
                 lambda kv:(kv[1], kv[0])))
